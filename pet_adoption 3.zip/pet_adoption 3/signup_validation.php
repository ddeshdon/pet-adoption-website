<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_OFF);


session_start();


$password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);


$mysqli = require __DIR__ . "/database-connection.php";
$role_id = 1; // Default role ID for new users
$sql = "INSERT INTO user (username, email, name, password_hash, role_ID) VALUES (?, ?, ?, ?, ?)";
$stmt = $mysqli->stmt_init();

if (!$stmt->prepare($sql)) {
    die("SQL error: " . $mysqli->error);
}


$stmt->bind_param("sssss", $_POST["username"], $_POST["email"], $_POST["name"], $password_hash, $role_id);

// Execute the query
if (!$stmt->execute()) {
    if ($stmt->errno == 1062) { // Duplicate 
        die("Email is already registered. Please use a different email.");
    } else {
        die("Execute failed: " . $stmt->error);
    }
} 

$new_user_id = $mysqli->insert_id;
$_SESSION["user_ID"] = $new_user_id;
header("Location: webpage1.php");
exit;
?>