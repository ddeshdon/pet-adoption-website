<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if(!isset($_SESSION["role_ID"]) || $_SESSION["role_ID"] !=2 ) {
    die("Access Denied: You do not have permission to perform this action.");  
}

$mysqli = require __DIR__ . "/database-connection.php";

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["user_id"])) {

    $user_id = intval($_POST["user_id"]);
    

     $check_query = "SELECT role_ID FROM user WHERE ID = ?";
     $check_stmt = $mysqli->prepare($check_query);
     $check_stmt->bind_param("i", $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $user_data = $check_result->fetch_assoc();

     if ($user_data && $user_data['role_ID'] == 2) {
         die("Cannot delete admin users.");
     }


    $delete_query = "DELETE FROM user WHERE ID = ?";
    $stmt = $mysqli->prepare($delete_query);
    $stmt->bind_param("i",$user_id);


    if($stmt->execute()) {
        header("Location: Admin1.php");
        exit;
    } else {
        die("Error deleting user: ". $mysqli->error);
    }
} else {
    die("Invalid Request.");
}

?>