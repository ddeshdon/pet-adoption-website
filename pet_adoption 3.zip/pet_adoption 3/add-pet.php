<?php

session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION["role_ID"]) || $_SESSION["role_ID"] != 2) {
    die("Access Denied: You do not have permission to perform this action.");
}

$mysqli = require __DIR__ . "/database-connection.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $petName = $_POST["petName"];
    $species = $_POST["species"];
    $breed = $_POST["breed"];
    $age = intval($_POST["age"]);
    $gender = $_POST["gender"];
    $description = $_POST["description"]; 
    $isVaccinated = ($_POST["vaccinated"] === "Yes") ? 1 : 0;

    
    echo "Description: " . htmlspecialchars($description) . "<br>";

    if (isset($_FILES["petPhoto"]) && $_FILES["petPhoto"]["error"] === UPLOAD_ERR_OK) {
        $photoTmpPath = $_FILES["petPhoto"]["tmp_name"];
        $photoName = basename($_FILES["petPhoto"]["name"]);
        $photoExtension = strtolower(pathinfo($photoName, PATHINFO_EXTENSION));
        $allowedExtensions = ["jpg", "jpeg", "png", "gif"];

        if (!in_array($photoExtension, $allowedExtensions)) {
            die("Invalid file type.");
        }

        $uploadDir = __DIR__ . "/pet_adoption/pet_images/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        $photoPath = $uploadDir . uniqid() . "." . $photoExtension;
        if (!move_uploaded_file($photoTmpPath, $photoPath)) {
            die("Error uploading the file.");
        }
        $photoPathForDB = "pet_adoption/pet_images/" . basename($photoPath);
    } else {
        die("Photo is required.");
    }

    
    $stmt = $mysqli->prepare("INSERT INTO pet (Name, Species, Breed, Age, Gender, is_adopted, Description, PhotoPath, is_vaccinated) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?)");
    $stmt->bind_param("sssisssi", $petName, $species, $breed, $age, $gender, $description, $photoPathForDB, $isVaccinated);

    
    if ($stmt->execute()) {
        header("Location: Petbrowsing.php");
        exit;
    } else {
        die("Error inserting pet details: " . $stmt->error);
    }
} else {
    die("Invalid Request.");
}
?>
