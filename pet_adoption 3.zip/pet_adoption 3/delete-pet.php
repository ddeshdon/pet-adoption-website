<?php
session_start();
$mysqli = require __DIR__ . "/database-connection.php";
if (!isset($_SESSION['role_ID']) || $_SESSION['role_ID'] != 2) {
    http_response_code(403);
    echo "Access denied.";
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pet_id'])) {
    $pet_id = (int)$_POST['pet_id'];
    $query = "DELETE FROM pet WHERE ID = ?";

    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("i", $pet_id);
    if ($stmt->execute()) {
        echo "Pet deleted successfully.";
        header("Location: Admin4.php"); 
    } else {
        echo "Error deleting pet: " . $stmt->error;
    }
} else {
    http_response_code(400);
    echo "Invalid request.";
}
?>