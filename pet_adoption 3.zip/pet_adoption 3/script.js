document.addEventListener("DOMContentLoaded", function() {
  const modal = document.getElementById("adoptModal");
  const closeBtn = document.querySelector(".close-btn");
  const petNameSpan = document.getElementById("petName");
  const petIdInput = document.getElementById("petId");

  // Event listener for each "Adopt Me" button
  document.querySelectorAll(".adopt-btn").forEach(button => {
      button.addEventListener("click", function() {
          const petName = button.getAttribute("data-pet-name");
          const petId = button.getAttribute("data-pet-id");

          // Set pet information in the modal
          petNameSpan.textContent = petName;
          petIdInput.value = petId;

          // Show the modal
          modal.style.display = "block";
      });
  });

  // Close the modal when the close button is clicked
  closeBtn.addEventListener("click", function() {
      modal.style.display = "none";
  });

  // Close the modal when clicking outside of the modal content
  window.addEventListener("click", function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  });
});