<?php
session_start();
$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"] === "POST"){
    $mysqli = require __DIR__ . "/database-connection.php";
    $sql = sprintf("SELECT * FROM user WHERE email = '%s'",$mysqli->real_escape_string($_POST["email"]));
    $result = $mysqli->query($sql);
    $user = $result -> fetch_assoc();
    
    if ($user) {
       if(password_verify($_POST["password"], $user["password_hash"])) {
        
        session_regenerate_id();
        $_SESSION["role_ID"] = $user["role_ID"];
        $_SESSION["user_ID"] = $user["ID"];
        
        if(isset($_GET['redirect'])){
            $redirecturl = $_GET['redirect'];
            header("Location: " . $redirecturl);
        } else {
            header("Location: webpage1.php");
        }
        exit;
       }
    }
    $is_invalid = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pet Haven - Login</title>
    <link rel="stylesheet" href="login.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

</head>
<body style="background-image:url('images/bg2.jpg'); background-size:cover;">
    <header>
        <div class="logoname">Love<span>Adopt</span> 🐾</div>
        <a href="webpage1.php" class="back-button">Back</a>
    </header>
    <main>
        <div class="container">
            <div class="login-box">
                <div class="logo">🐾</div>
                <h2>Sign in with email</h2>
                <p>Make a new doc to bring your words, data, and teams together. For free</p>
                <form method = "post">
                <input type="email" name="email" placeholder="email" required>
                <input type="password" name="password" placeholder="password" required>
                    <button type="submit">Get Started</button>
                    <div class="social-icons">
                        <?php if ($is_invalid): ?>
                        <em>Invalid login</em>
                        <?php endif; ?>
                    </div>
                </form>
                <p>Don't have an account? <a href="signup.html">Sign up here</a>.</p>
            </div>
        </div>
    </main>
</body>
</html>
