<?php
session_start();

if (isset($_SESSION["user_ID"])){
    $mysqli = require __DIR__. "/database-connection.php";
    $sql = "SELECT * FROM user WHERE ID = {$_SESSION["user_ID"]}";
    $result = $mysqli->query($sql);
    $user = $result->fetch_assoc();
    $pet_query = "SELECT ID, Name, Species, Breed, Age, Gender, Description, PhotoPath FROM pet WHERE is_adopted = 0";
    $pet_result = $mysqli->query($pet_query);
    
}
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Love Adopt</title>
    <link rel="stylesheet" href="webpage1.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">

</head>
<body>
<header>
        <div class="logo">Love<span>Adopt</span> 🐾</div>
            <?php if (isset($user)): ?>
                <div class="welcome-user">
                    <p> Welcome <?= htmlspecialchars($user["name"]) ?></p>
                </div>
                <div class="nav">
                    <nav>
                        <a href="webpage1.php">Home</a>
                        <a href="About.php">About us</a>
                        <a href="Petbrowsing.php">Pets</a>
                        <a href="Userprofile.php">Profile</a>
                        <?php if (isset($_SESSION["role_ID"]) && $_SESSION["role_ID"] == 2): ?>
                    <a href="Admin1.php">Admin Panel</a> 
                <?php endif; ?>
                    </nav>    
                </div>
                <div class="logout-button">
                    <a href = "logout.php" class = "login-button">Logout</a>
                </div>     
            <?php else: ?>
                <div class="logout-button">
                    <a href = "login.php" class="login-button">Log in</a> or <a href = "signup.html" class="login-button">sign up</a>
                </div>
            <?php endif; ?>
            
        
    </header>
    
    
    <section class="hero">
        <div class="hero-content">
            <h1>Ad<span style=" font-family:Dela Gothic One;color: rgb(183, 121, 241); font-weight: bold;font-size: 80px;" >o</span>pt l<span style=" font-family:Dela Gothic One;color: rgb(121, 165, 241); font-weight: bold;font-size: 80px;" >o</span>ve,</h1>
            <h1>f<span style="font-family:Dela Gothic One;color: rgb(239, 144, 182); font-weight: bold;font-size: 80px;">o</span>ster happiness.</h1>
        </div>
        <div class="hero-image">
          <div class="review-avatars">
            <p>Our happy pet owners</p>
                <span>⭐ <span style="font-weight: 600;">4.8 </span>(1.5k Reviews)</span>
                <div class="userpic-container">
                  <img class="userpic" src="images/profile1.jpg">
                  <img class="userpic" src="images/profile2.jpg">
                  <img class="userpic" src="images/profile3.jpg">
                  <img class="userpic" src="images/profile4.jpg">
                </div>
                <div class="description2">
                    <h2>Want to know more about us?</h2>
                    <p style="font-weight:400">Learn more about our mission, values, and the story behind what we do on our About Us page!</p>
                    <a href="About.php" class="learn-more-button">Learn more</a>
                </div>
          </div>
            <img src="corgi.png" alt="Happy Dog">
            <div class="description">
                <h2>What we do?</h2>
                <p>With a focus on matching the right pet with the right family, LoveAdopt makes it easy to adopt love and foster happiness.</p>
                <a href="Petbrowsing.php" class="view-pets-button">View pets</a>
            </div>
        </div>
    </section>
  </section>
 <script src="scroll.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
  <script src="scripts.js"></script>

</body>
</html>
