
<?php
session_start();

if (!isset($_SESSION["user_ID"])) {
    header("Location: login.php");
    exit;
}

$mysqli = require __DIR__ . "/database-connection.php";

$user_id = $_SESSION["user_ID"];
$user_query = "SELECT name, email, username FROM user WHERE ID = ?";
$user_stmt = $mysqli->prepare($user_query);
$user_stmt -> bind_param("i",$user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();
$adoption_query = "SELECT 
    adoption_request.pet_name, 
    adoption_request.pet_description, 
    adoption_status.status 
    FROM adoption_request
    LEFT JOIN adoption_status ON adoption_request.ID = adoption_status.adoption_request_id
    WHERE adoption_request.user_id = ?";
$adoption_stmt = $mysqli->prepare($adoption_query);
$adoption_stmt->bind_param("i", $user_id);
$adoption_stmt->execute();
$adoption_result = $adoption_stmt->get_result();
$adoption_requests = $adoption_result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Profile</title>
  <link rel="stylesheet" href="Userprofile.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">
</head>
<body>

<!-- Header -->
<header>
  <div class="logo">Love<span>Adopt</span> 🐾</div>
  <nav>
      <a href="webpage1.php">Home</a>
      <a href="About.php">About us</a>
      <a href="Petbrowsing.php">Pets</a>
      <a href="Userprofile.php">Profile</a>
      <?php if (isset($_SESSION["role_ID"]) && $_SESSION["role_ID"] == 2): ?>
          <a href="Admin1.php">Admin Panel</a>
      <?php endif; ?>
  </nav>
  <?php if (isset($_SESSION["user_ID"])): ?>
      <a href="logout.php" class="login-button">Logout</a>
  <?php else: ?>
      <a href="login.php" class="login-button">Login</a>
  <?php endif; ?>
</header>

<div class="profile-container">
    <!-- Sidebar with User Information -->
    <div class="sidebar">
        <img src="images/my-channel.jpeg" alt="Profile Picture">
        <h2><?= htmlspecialchars($user["name"]) ?></h2>
        <div class="username">@<?= htmlspecialchars($user["username"]) ?></div>
        <ul>
            <a href="#1">Profile</a>
            <a href="#2">Adoption Requests</a>
            
            <a href="logout.php">Logout</a>
        </ul>
    </div>

    <!-- Content Section -->
    <div class="content">
        <div id="1">
            <h1>User Profile</h1>
            <!-- User Information Section -->
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" value="<?= htmlspecialchars($user["name"]) ?>" disabled>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" value="<?= htmlspecialchars($user["email"]) ?>" disabled>
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" value="<?= htmlspecialchars($user["username"]) ?>" disabled>
            </div>
        </div>
    

        <!-- Pet Adoption Tracking Section -->
        <div id="2">
            <h2>Pet Adoption Tracking</h2>
            <div class="adoption-tracking">
                <?php if ($adoption_requests): ?>
                    <?php foreach ($adoption_requests as $request): ?>
                        <div class="tracking-item">
                            <p><strong>Pet Name: </strong> <?= htmlspecialchars($request["pet_name"]) ?></p>
                            <p><strong>Description: </strong><?=htmlspecialchars($request["pet_description"]) ?></p>
                            <p><strong>Status: </strong> 
                                <span class="status <?= htmlspecialchars(strtolower($request["status"])) ?>">
                                    <?=htmlspecialchars($request["status"]) ?>
                                </span>
                            </p>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No adoption request found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<script src="scroll.js"></script>
</body>
</html>
