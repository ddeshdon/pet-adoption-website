
<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
if (!isset($_SESSION["user_ID"]) || $_SESSION["role_ID"] != 2) {
    header("Location: login.php"); 
    exit;
}
require __DIR__ . "/database-connection.php";

$user_id = $_SESSION["user_ID"];
$user_query = "SELECT * FROM user WHERE ID = ?";
$user_stmt = $mysqli->prepare($user_query);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

$query = "SELECT 
    adoption_request.ID AS request_id,
    adoption_request.pet_id,
    adoption_request.name_form AS user_name,
    adoption_request.email_form,
    adoption_request.phone_form,
    adoption_request.pet_name,
    adoption_request.UserFormRequest,
    adoption_request.current_city_form,
    adoption_request.current_country_form,
    adoption_request.nationality_form,
    adoption_status.status
FROM adoption_request
LEFT JOIN adoption_status ON adoption_request.ID = adoption_status.adoption_request_id
WHERE adoption_status.status IS NULL OR adoption_status.status = 'Pending'";

$result = $mysqli->query($query);
$requests = $result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER["REQUEST_METHOD"] === "POST"){
    $request_id = $_POST['request_id'];
    $pet_id = $_POST['pet_id'];
    $action = $_POST['action'];
    if (!$request_id || !$pet_id) {
        die("Invalid request: Missing required parameters.<br>" . 
            "Request ID: " . htmlspecialchars($request_id) . "<br>" . 
            "Pet ID: " . htmlspecialchars($pet_id) . "<br>" . 
            "Action: " . htmlspecialchars($action) . "<br>");
    }

    if ($action === "approve") {
        $status_update = "UPDATE adoption_status SET status = 'Approved' WHERE adoption_request_id = ?";
        $pet_update = "UPDATE pet SET is_adopted = 1 WHERE ID = ?";
    } elseif ($action === "reject"){
        $status_update = "UPDATE adoption_status SET status = 'Rejected' WHERE adoption_request_id = ?";
    }
    if (isset($status_update)){
        $stmt = $mysqli->prepare($status_update);
        $stmt->bind_param("i",$request_id);
        $stmt->execute();
    }
    if(isset($pet_update)){
        $stmt = $mysqli->prepare($pet_update);
        $stmt->bind_param("i",$pet_id);
        $stmt->execute();
    }
    header("Location: Admin2.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin View - Manage Users</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="Admin.css">
</head>
<body>

<!-- Header -->
<header>
  <div class="logo">Love<span>Adopt</span> 🐾</div>
  <nav>
      <a href="webpage1.php">Home</a>
      <a href="About.php">About us</a>
      <a href="Petbrowsing.php">Pets</a>
      <a href="Userprofile.php">Profile</a>
      <a href="Admin1.php">Admin Panel</a>
  </nav>
  <a href="logout.php" class="login-button">Logout</a>
</header>

<div class="admin-container">
    <!-- Sidebar with Admin Controls -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <a href="Admin1.php">Manage Users</a>
            <a href="Admin4.php">Manage Pets</a>
            <a href="Admin2.php">Adoption Requests</a>
            <a href="Admin3.html">Add Pets</a>
        </ul>
    </div>

    <!-- Main Content Section -->
    <div class="content">
        <!-- Adoption Requests Section -->
        <h1>Adoption Requests</h1>
        <table class="request-table">
            <thead>
                <tr>
                    <th>Request ID</th>
                    <th>User Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Pet Name</th>
                    <th>Status</th>
                    <th>Actions</th>
                    <th>Form Answers</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($requests as $request): ?>
                <tr>
                    <td><?= htmlspecialchars($request['request_id']) ?></td>
                    <td><?= htmlspecialchars($request['user_name']) ?></td>
                    <td><?= htmlspecialchars($request['email_form']) ?></td>
                    <td><?= htmlspecialchars($request['phone_form']) ?></td>
                    <td><?= htmlspecialchars($request['pet_name']) ?></td>
                    <td><?= htmlspecialchars($request['status'] ?? 'Pending') ?></td>
                    <td>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="request_id" value="<?= $request['request_id'] ?>">
                            <input type="hidden" name="pet_id" value="<?= $request['pet_id'] ?>">
                             <button type="submit" name="action" value="approve" class="action-btn approve">Approve</button>
                        </form>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="request_id" value="<?= $request['request_id'] ?>">
                            <input type="hidden" name="pet_id" value="<?= $request['pet_id'] ?>">
                            <button type="submit" name="action" value="reject" class="action-btn reject">Reject</button>
                        </form>
                    </td>
                    <td>
                        <img class="form-bt" src="images/form.png" alt="Form Icon" onclick="openPopup('popup-<?= $request['request_id'] ?>')">
                         <!-- Popup Overlay -->
                         <div class="popup-overlay" id="popup-overlay-<?= $request['request_id'] ?>" onclick="closePopup('popup-<?= $request['request_id'] ?>')"></div>
                            
                        <!-- Popup Form -->
                        <div class="popup-form" id="popup-<?= $request['request_id'] ?>">
                            <button class="close-btn" onclick="closePopup('popup-<?= $request['request_id'] ?>')">X</button>
                            <h2>Adoption Request</h2>
                            <p><strong>Name:</strong> <?= htmlspecialchars($request['user_name']) ?> </p>
                            <p><strong>Nationality:</strong> <?= htmlspecialchars($request['nationality_form']) ?></p>
                            <p><strong>Current City:</strong> <?= htmlspecialchars($request['current_city_form']) ?></p>
                            <p><strong>Current Country:</strong> <?= htmlspecialchars($request['current_country_form']) ?> </p>
                            <p><strong>Contact:</strong> <?= htmlspecialchars($request['email_form']) ?></p>
                            <p><strong>Phone:</strong> <?= htmlspecialchars($request['phone_form']) ?></p>
                            <p><strong>Reason for Adoption:</strong> <?= htmlspecialchars($request['UserFormRequest']) ?> </p>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($requests)): ?>
                <tr>
                    <td colspan="8">No pending requests found.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="js/form-popup.js"></script>
</body>
</html>
