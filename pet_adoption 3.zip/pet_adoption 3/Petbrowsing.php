<?php 
session_start();
$mysqli = require __DIR__ . "/database-connection.php";

$pet_query = "SELECT ID,Name, Species, Breed, Age, Gender, Description, PhotoPath FROM pet WHERE is_adopted = 0";
$pet_result = $mysqli->query($pet_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pet Foster - Browse Pets</title>
<link rel="stylesheet" href="PetBrowsing.css">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

</head>
<body>

<!-- Header -->
<header>
  <div class="logo">Love<span>Adopt</span> 🐾</div>
  <nav>
    <a href="webpage1.php">Home</a>
    <a href="About.php">About us</a>
    <a href="Petbrowsing.php">Pets</a>
    <a href="Userprofile.php">Profile</a>
    <?php if (isset($_SESSION["role_ID"]) && $_SESSION["role_ID"] == 2): ?>
        <a href="Admin1.php">Admin Panel</a>
    <?php endif; ?>
</nav>
<?php if (isset($_SESSION["user_ID"])): ?>
    <a href="logout.php" class="login-button">Logout</a>
<?php else: ?>
    <a href="login.php" class="login-button">Login</a>
<?php endif; ?>
</header>

<!-- Main Content -->
<div class="main-content">
  <div class="design6-container">
    <img class="design6" src="images/design6.png">
  </div>
  <div class="design7-container">
    <img class="design7" src="images/design7.png">
  </div>
  <div class="design8-container">
    <img class="design8" src="images/design8.png">
  </div>
  <div class="title-section">
      <h1>Find Your New <span class="highlight">Best Friend</span></h1>
      <p>Explore a variety of pets looking for a loving home. Adopt love, foster happiness.</p>
  </div>

  <!-- Pet Cards Section -->
  <div class="pet-container">
    <?php while ($pet = $pet_result->fetch_assoc()): ?>
    <div class="pet-card">
        <img src="<?= htmlspecialchars($pet['PhotoPath']) ?>" alt="<?= htmlspecialchars($pet['Name']) ?>">
        <h2><?= htmlspecialchars($pet['Name']) ?></h2>
        <p><strong>Species:</strong> <?= htmlspecialchars($pet['Species']) ?></p>
        <p><strong>Breed:</strong> <?= htmlspecialchars($pet['Breed']) ?></p>
        <p><strong>Age:</strong> <?= htmlspecialchars($pet['Age']) ?> years</p>
        <p><strong>Gender:</strong> <?= htmlspecialchars($pet['Gender']) ?></p>
        
        <?php if (isset($_SESSION['user_ID'])): ?>
            <a href="pet_form.php?pet_id=<?= $pet['ID'] ?>" class="adopt-btn">Adopt me</a>
        <?php else: ?>
            <a href="login.php?redirect=pet_form.php?pet_id=<?= $pet['ID'] ?>" class="adopt-btn">Adopt me</a>
        <?php endif; ?>    
    </div>
    <?php endwhile; ?>
</div>
        


</body>
</html>
