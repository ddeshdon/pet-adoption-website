<?php

session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


if (isset($_SESSION['user_ID'])) {
    $mysqli = require __DIR__ . "/database-connection.php";

    $sql = "SELECT * FROM user WHERE ID = {$_SESSION['user_ID']}";
    $result = $mysqli->query($sql);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        echo "No user found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Pet Adoption</title>
   
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="About.css">
</head>
<body>
  <header>
    <div class="logo">Love<span>Adopt</span> 🐾</div>
    <nav>
        <a href="webpage1.php">Home</a>
        <a href="About.php">About us</a>
        <a href="Petbrowsing.php">Pets</a>
        <a href="Userprofile.php">Profile</a>
        <?php if (isset($_SESSION["role_ID"]) && $_SESSION["role_ID"] == 2): ?>
          <a href="Admin1.php">Admin Panel</a>
        <?php endif; ?>
    </nav>
    <div class = "logout-button">
      <?php if (isset($_SESSION["user_ID"])): ?>
        <a href="logout.php" class = "login-button">Logout</a>
      <?php else: ?>
        <a href="login.php" class = "login-button">Log in</a> or <a href="signup.html" class="login-button">Sign up</a>
        <?php endif; ?>
    </div>
  </header>
  
  <main>
    <div class="header-content">
      <div class="line1-container">
        <img class="line1" src="images/line1.png">
      </div>
      <div class="design1-container">
        <img class="design1" src="images/design1.png">
      </div>
      <div class="design2-container">
        <img class="design2" src="images/design2.png">
      </div>
      
      <div class="text-part">
        <h2>The path to a happier life <span class="highlight1">just got brighter!</span></h2>
        <p>
          At LoveAdopt, we are dedicated to ensuring every animal finds a loving home and every family discovers the joy of pet companionship. Our mission extends beyond adoption—we aim to educate pet owners, promote animal welfare, and foster a compassionate community. LoveAdopt is here to guide and support you.
        </p>
        <div class="button-part">
          <a href="#1" class="button">Learn More</a>
        </div>
        
      </div>
      <div class="pic-part">
        <img src="images/about1.png">
      </div>   
    </div>
    <section class="choose-path" id="1">
      <h3>Choose Your Path</h3>
      <div class="cards">
        <div class="card">
          <h4>Adopt a Pet</h4>
          <img class="pic-icon2" src="images/choose-path2.png">
          <p>Find your new best friend from our database of lovable pets.</p>
          <a href="Petbrowsing.php" class="link">Explore</a>
        </div>
        <div class="card">
          <h4>Volunteer</h4>
          <img class="pic-icon1" src="images/choose-path1.png">
          <p>Make a difference by offering your time and love to our rescue centers.</p>
          <a href="#" class="link">Join Us</a>
        </div>  
        <div class="card">
          <h4>Donate</h4>
          <img class="pic-icon3" src="images/choose-path3.png">
          <p>Help us continue rescuing animals by supporting our mission.</p>
          <a href="#" class="link">Donate Now</a>
      </div>
    </section>
    <section class="meet-team">
      <div class="design4-container">
        <img class="design4" src="images/design4.png">
      </div>
      <img class="stupid-desh" src="images/edesh.png">
      <div class="meet-team-right">
        <p>CEO & FOUNDER of LoveAdopt🐾</p>
        <h3>Meet Deshdon</h3>
        <p class="first-paragraph"> 
          Our dedicated team of animal lovers comes from all walks of life but shares a common goal: to improve the lives of pets and their future families. 
        </p>
        <p class="second-paragraph">
          From our tireless volunteers to our compassionate shelter staff, each person plays a vital role in ensuring every animal receives the care, attention, and love they deserve. Learn more about the individuals behind Pet Haven and how they contribute to our success.
        </p>
        <div class="button-part">
          <a href="https://www.youtube.com/watch?v=Gnm3hIcjiCQ" class="button">Learn More</a>
        </div>
      </div>
      
    </section>
    <section class="trusted">
      <h3><span class="highlight1"> TRUSTED BY & FEATURED IN</span></h3>
      <div class="logos">
        <img src="images/logo2.png" alt="Logo 2">
        <img src="images/logo3.png" alt="Logo 3">
        <img src="images/logo4.png" alt="Logo 4">
        <img src="images/logo5.png" alt="Logo 5">
        <img src="images/logo6.png" alt="Logo 6">
        <img src="images/logo8.png" alt="Logo 8">
        <img src="images/siit-logo.png" alt="Logo 4">
      </div>
    </section>
    <div class="curvy-line">
      <img src="images/curvy-line.png">
    </div>
    <section class="contact"> 
      <div class="contact-info">
        <h5>
          Contact Us
        </h5>
        <div class="info-box">
          <div>
            <p>Email: info@LoveAdopt.com</p>
          </div>
          <div>
            <p>Tel: 1-800-LOVE-PET</p>
          </div>
          <div>
            <p>Facebook: <span class="underline">www.facebook.com/loveadopt</span></p>
          </div> 
        </div> 
      </div>
      <div class="map-container">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3870.084402526788!2d100.60305527543946!3d14.072193086353941!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30e27fecb1e8d73f%3A0xe114a07c97a9a674!2z4Lih4Lir4Liy4Lin4Li04LiX4Lii4Liy4Lil4Lix4Lii4LiY4Lij4Lij4Lih4Lio4Liy4Liq4LiV4Lij4LmMIOC4qOC4ueC4meC4ouC5jOC4o-C4seC4h-C4quC4tOC4lQ!5e0!3m2!1sth!2sth!4v1732631538951!5m2!1sth!2sth" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>    
  </main>
</body>
<script src="scroll.js"></script>
</html>
