const validation = new JustValidate('#signup', {
  errorLabelCssClass: 'error-message', // Style for error labels
});

validation
.addField('#email', [
  {
      rule: 'required',
      errorMessage: 'Email is required',
  },
  {
      rule: 'email',
      errorMessage: 'Please enter a valid email',
  },
  {
      validator: (value) => () => {
          return fetch("validate-email.php?email=" + encodeURIComponent(value))
          .then(response => response.json())
          .then(json => {
              console.log("Validation response:", json); // Debugging log
              return json.available; // Ensure it matches PHP output
          })
          .catch(error => {
              console.error("Error during validation:", error);
              return false; // Fails validation on error
          });
      },
      errorMessage: "Email already taken",
  }
])
.addField('#name', [
  {
      rule: 'required',
      errorMessage: 'Name is required',
  },
])
.addField('#username', [
  {
      rule: 'required',
      errorMessage: 'Username is required',
  },
])
.addField('#password', [
  {
      rule: 'required',
      errorMessage: 'Password is required',
  },
  {
      rule: 'minLength',
      value: 6,
      errorMessage: 'Password must be at least 6 characters',
  },
])
.addField('#confirm_password', [
  {
      rule: 'required',
      errorMessage: 'Please confirm your password',
  },
  {
      validator: (value, fields) => {
          const password = fields['#password'].elem.value;
          return value === password; // Passwords must match
      },
      errorMessage: 'Passwords do not match',
  },
])
.onSuccess((event) => {
  event.preventDefault(); // Prevent default submission
  console.log("Form is valid!");
  document.getElementById("signup").submit();
});
