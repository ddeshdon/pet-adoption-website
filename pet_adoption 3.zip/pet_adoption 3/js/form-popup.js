function openPopup(popupId) {
  document.getElementById(popupId).style.display = 'block';
  document.getElementById('popup-overlay-' + popupId.split('-')[1]).style.display = 'block';
}

function closePopup(popupId) {
  document.getElementById(popupId).style.display = 'none';
  document.getElementById('popup-overlay-' + popupId.split('-')[1]).style.display = 'none';
}
