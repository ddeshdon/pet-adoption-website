


<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
if (!isset($_SESSION["user_ID"]) || $_SESSION["role_ID"] != 2) {
    header("Location: login.php"); 
    exit;
}

$mysqli = require __DIR__ . "/database-connection.php";
$user_query = "SELECT ID, name, email FROM user";
$user_result = $mysqli->query($user_query);
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin View - Manage Users</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

<link rel="stylesheet" href="Admin.css">
</head>
<body>

<!-- Header -->
<header>
  <div class="logo">Love<span>Adopt</span> 🐾</div>
  <nav>
      <a href="webpage1.php">Home</a>
      <a href="About.php">About us</a>
      <a href="Petbrowsing.php">Pets</a>
      <a href="Userprofile.php">Profile</a>
      <a href="Admin1.php">Admin Panel</a>
  </nav>
  <a href="logout.php" class="login-button">Logout</a>
</header>

<div class="admin-container">
    <!-- Sidebar with Admin Controls -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <a href="Admin1.php">Manage Users</a>
            <a href="Admin4.php">Manage Pets</a>
            <a href="Admin2.php">Adoption Requests</a>
            <a href="Admin3.html">Add Pets</a>
        </ul>
    </div>

    <!-- Main Content Section -->
    <div class="content">
        <!-- User Management Section -->
        <h1>Manage Users</h1>
        <table class="user-table">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Actions</th>

                </tr>
            </thead>
            <tbody>
                <?php while ($row = $user_result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['ID']) ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td>
                        
                    <form action="delete-user.php" method="POST" style="display:inline;">
                        <input type="hidden" name="user_id" value="<?= htmlspecialchars($row['ID']) ?>">
                        <button type="submit" class="action-btn delete-user">Delete</button>
                    </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
