<?php

session_start();
require __DIR__ . "/database-connection.php";
// Check if the user is logged in or not if not go to login page
if (!isset($_SESSION['user_ID'])) {
    header("Location: login.php");
    exit;
}
// Fetch the user's email
$user_id = $_SESSION['user_ID'];
$user_query = "SELECT email FROM user WHERE ID = ?";
$stmt = $mysqli->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();
if (!$user) {
    die("User not found.");
}
$user_email = $user['email'];

if (!isset($_GET['pet_id'])) {
    die("Invalid request");
}

$pet_id = (int) $_GET['pet_id']; 
$pet_query = "SELECT * FROM pet WHERE ID = ? AND is_adopted = 0";
$stmt = $mysqli->prepare($pet_query);
$stmt->bind_param("i", $pet_id);
$stmt->execute();
$pet_result = $stmt->get_result();
if ($pet_result->num_rows === 0) {
    die("Pet not found");
}
$pet = $pet_result->fetch_assoc();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $email = $user_email;
    $phone = $_POST['phone'];
    $nationality = $_POST['nationality'];
    $city = $_POST['city'];
    $country = $_POST['country'];
    $message = $_POST['message'];
    $user_id = $_SESSION['user_ID'] ?? null;

    $insert_query = "INSERT INTO adoption_request (user_id, name_form, email_form, phone_form, nationality_form, current_city_form, current_country_form, pet_id, pet_name, pet_description, UserFormRequest) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $mysqli->prepare($insert_query);
    $stmt->bind_param(
        "issssssisss",
        $user_id,
        $name,
        $email,
        $phone,
        $nationality,
        $city,
        $country,
        $pet_id,
        $pet['Name'],
        $pet['Description'],
        $message
    );

    if ($stmt->execute()) {
      $adoption_status_query = "INSERT INTO adoption_status(adoption_request_id, user_ID, user_name, pet_ID, pet_name, status) VALUES (?, ?, ?, ?, ?, 'Pending')";
      $adoption_request_id = $stmt->insert_id;
      $status_stmt = $mysqli->prepare($adoption_status_query);
      $status_stmt->bind_param(
          "iisis",
          $adoption_request_id,
          $user_id,
          $name,
          $pet_id,
          $pet['Name']
      );
      $status_stmt->execute();
      header("Location: Userprofile.php");
      exit;
  } else {
      echo "<p>Error: Could not submit your request. Please try again.</p>";
  }
}
  
?>




<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pet Information</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: Poppins
      margin: 0;
      padding: 0;
      background-color: #f5f8fa;
    }
    .container {
      max-width: 900px;
      margin: 0 auto;
      padding: 20px;
    }
    h1 {
      text-align: center;
      color: #333;
    }
    .pet-container {
      background: #fff;
      padding: 20px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
      margin-top: 20px;
    }
    .pet-image img {
      display: block;
      max-width: 400px;
      height: auto;
      border-radius: 8px;
      margin: 0 auto 20px;
    }
    .pet-info {
      font-size: 18px;
      color: #555;
      line-height: 1.6;
    }
    .pet-info p {
      margin: 5px 0;
    }
    .back-bt{
      background-color: grey;
      border-radius:20px;
      padding:10px 20px;
      text-decoration: none;
      color:white;
    }
  </style>
</head>
<body>
  
  <div class="container">
  <a href="Petbrowsing.php" class="back-bt">X</a>
    <h1>Adopt <?= htmlspecialchars($pet['Name']) ?></h1>
    <div class="pet-container">
      <!-- Pet Image -->
      <div class="pet-image">
      <img src="<?= htmlspecialchars($pet['PhotoPath']) ?>" alt="<?= htmlspecialchars($pet['Name']) ?>">
      </div>
      <!-- Pet Details -->
      <div class="pet-info">
      <p><strong>Species:</strong> <?= htmlspecialchars($pet['Species']) ?></p>
        <p><strong>Breed:</strong> <?= htmlspecialchars($pet['Breed']) ?></p>
        <p><strong>Age:</strong> <?= htmlspecialchars($pet['Age']) ?> years</p>
        <p><strong>Gender:</strong> <?= htmlspecialchars($pet['Gender']) ?></p>
        <p><strong>Description:</strong> <?= htmlspecialchars($pet['Description']) ?></p>
      </div>
    </div>
  </div>
</body>
</html>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Information with Adoption Process</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&display=swap" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: Poppins, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f7f2e6;
    }
    .container {
      max-width: 900px;
      margin: 0 auto;
      padding: 20px;
    }
    h1, h2 {
      font-size:39px;
      text-align: center;
      color: #333;
    }
    .adoption-process {
      text-align: center;
      margin: 40px 0;
    }
    .adoption-steps {
      display: flex;
      justify-content: space-between;
      flex-wrap: wrap;
      margin-top: 20px;
    }
    .step {
      flex: 1;
      max-width: 200px;
      margin: 10px;
      text-align: center;
      margin-top: auto; /* Pushes the link to the bottom if there’s extra space */
      background-color:#bfc5ed;
      border-radius:10px;
      padding:14px;
    }
    .step p{
      flex-grow: 1; /* Ensures the paragraph stretches to create equal spacing */
      max-width: 200px;
      margin: 10px;
      text-align: center;
      
    }
    .img {
      width: 50px;
      margin-bottom: 10px;

    }
    .img3 {
      width: 70px;
      height: 50px;
      margin-bottom: 10px;
    }
    .form-container {
      background: #fff;
      padding: 20px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      border-radius: 8px;
    }
    .form-group {
      margin-bottom: 15px;
    }
    label {
      display: block;
      font-weight: bold;
      margin-bottom: 5px;
    }
    input, select, textarea {
      width: 100%;
      padding: 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }
    textarea {
      height: 100px;
    }
    button {
      width: 100%;
      padding: 10px;
      background-color: #a1785c;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
    }
    button:hover {
      background-color: #795644;
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Adoption Process Section -->
    <section class="adoption-process">
      <h2>Adoption Process</h2>
      <div class="adoption-steps">
        <div class="step">
          <img class="img"src="images/fill-out.png" alt="img">
          <p>1. Fill out the adoption form</p>
        </div>
        <div class="step">
          <img class="img" src="images/form.png" alt="Review Icon">
          <p>2. We Review Your Application</p>
        </div>
        <div class="step">
          <img class="img3"src="images/phone.png" alt="Phone Call Icon">
          <p>3. We Setup a Phone Call</p>
        </div>
        <div class="step">
          <img class="img" src="images/choose-path2.png" alt="Animal Icon">
          <p>4. You Meet Your Animal</p>
        </div>
      </div>
    </section>

    <!-- User Information Form -->
    <div class="form-container">
      <h1>User Information</h1>
      <form method="POST">
        <!-- First Name -->
        <div class="form-group">
          <label for="name">Your Name</label>
          <input type="text" id="name" name="name" placeholder="Enter your first name" required>
        </div>

        <!-- Email Address -->
        <div class="form-group">
          <label for="email">Email Address *</label>
          <input type="email" id="email" name="email" value="<?= htmlspecialchars($user_email) ?>" readonly>
        </div>
        <!-- Phone -->
        <div class="form-group">
          <label for="phone">Phone *</label>
          <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required>
        </div>
        <!-- Nationality -->
        <div class="form-group">
          <label for="nationality">Nationality</label>
          <select id="nationality" name="nationality">
            <option value="">Select your nationality</option>
            <option value="thai">Thai</option>
            <option value="american">American</option>
            <option value="british">British</option>
            <option value="other">Other</option>
          </select>
        </div>
        <!-- Current City -->
        <div class="form-group">
          <label for="city">City</label>
          <input type="text" id="city" name="city" placeholder="Enter your current city">
        </div>
        <!-- Current Country -->
        <div class="form-group">
          <label for="country">Country</label>
          <input type="text" id="country" name="country" placeholder="Enter your current country">
        </div>
        <!-- Message -->
        <div class="form-group">
          <label for="message">Why do you want to adopt?</label>
          <textarea id="message" name="message" placeholder="Enter your message" required></textarea>
        </div>
        
        <button type="submit">Submit Application</button>
      </form>
    </div>
  </div>
</body>
</html>
